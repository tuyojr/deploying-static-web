1. https://d30mq0u4lgud00.cloudfront.net/

2. http://mystatic-137477952140-bucket.s3-website.us-east-1.amazonaws.com/

3. http://mystatic-137477952140-bucket.s3.amazonaws.com/index.html